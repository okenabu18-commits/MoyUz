MOYUZ - GITHUB ORQALI TERMINALSIZ EXE YARATISH

1) github.com ga kiring, account yarating yoki login qiling.
2) New repository bosing. Repository name: MoyUz. Private tanlashingiz mumkin.
3) Create repository bosing.
4) Add file -> Upload files orqali SHU PAPKANING ICHIDAGI fayllarni yuklang:
   package.json, main.js, index.html, assets papkasi.
5) MUHIM: GitHub veb sahifasida yashirin .github papkasi yuklanmay qolsa,
   Add file -> Create new file ni tanlang va filename maydoniga
   .github/workflows/build-windows.yml deb yozing.
   Shu ZIP ichidagi .github/workflows/build-windows.yml matnini nusxalab
   joylang va Commit changes bosing.
6) GitHub -> Actions -> Build MoyUz Windows EXE -> Run workflow.
   (Agar push avtomatik boshlagan bo'lsa, qayta ishga tushirish shart emas.)
7) Build yashil tugagach -> ishga tushgan workflow -> Artifacts ->
   MoyUz-Windows-EXE ni yuklab oling va ZIPdan chiqaring.
8) MoyUz Setup.exe ni ikki marta bosib o'rnating.

Izoh: GitHub Actions faylni Windows serverda yig'adi. Bu yerda EXE hali
build qilinmagan, shuning uchun muvaffaqiyatli ishlashini oldindan
kafolatlab bo'lmaydi. Ilova kodi offline index.html asosida ishlaydi.
Windows SmartScreen imzosiz dastur uchun ogohlantirish berishi mumkin.
