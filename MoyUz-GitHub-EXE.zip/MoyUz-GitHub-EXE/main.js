const { app, BrowserWindow, shell } = require('electron');
const path = require('node:path');
app.setAppUserModelId('uz.moyuz.desktop');
function createWindow() {
  const win = new BrowserWindow({
    width: 1360, height: 850, minWidth: 900, minHeight: 600,
    title: 'MoyUz', backgroundColor: '#091324',
    icon: path.join(__dirname, 'assets', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: { nodeIntegration: false, contextIsolation: true, sandbox: true }
  });
  win.loadFile(path.join(__dirname, 'index.html'));
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}
app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
